import { motion } from 'framer-motion';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import Footer from '../components/Footer';

const serviceCards = [
  {
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8e6?w=600&q=80',
    caption: 'Professional photo editing to enhance your images.',
  },
  {
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&q=80',
    caption: 'Innovative software solutions tailored for your needs.',
  },
  {
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&q=80',
    caption: 'Reliable engineering services for your projects success.',
  },
];

export default function Home() {
  return (
    <div className="page">
      <Navbar transparent />
      <Hero />

      <section id="services" className="home-cards">
        {serviceCards.map((card, i) => (
          <motion.div
            key={card.caption}
            className="home-card"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: i * 0.15 }}
          >
            <div className="home-card__image">
              <img src={card.image} alt={card.caption} />
            </div>
            <p className="home-card__caption">{card.caption}</p>
          </motion.div>
        ))}
      </section>

      <Footer />
    </div>
  );
}
