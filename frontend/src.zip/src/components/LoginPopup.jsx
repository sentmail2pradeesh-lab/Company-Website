import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../context/AuthContext';
import Input from './Input';
import Button from './Button';
import './components.css';

export default function LoginPopup() {
  const { isLoginOpen, closeLogin, login, forgotPassword } = useAuth();
  const [view, setView] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  const resetForm = () => {
    setEmail('');
    setPassword('');
    setMessage({ type: '', text: '' });
    setView('login');
  };

  const handleClose = () => {
    closeLogin();
    resetForm();
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ type: '', text: '' });
    try {
      await login(email, password);
      resetForm();
    } catch (err) {
      setMessage({
        type: 'error',
        text: err.response?.data?.message || 'Login failed. Please try again.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleForgot = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ type: '', text: '' });
    try {
      const res = await forgotPassword(email);
      setMessage({ type: 'success', text: res.message });
    } catch (err) {
      setMessage({
        type: 'error',
        text: err.response?.data?.message || 'Could not send reset link.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isLoginOpen && (
        <>
          <motion.div
            className="login-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
          />
          <motion.aside
            className="login-popup"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 260 }}
          >
            <div className="login-popup__header">
              <h2 className="login-popup__title">
                {view === 'login' ? 'Welcome Back' : 'Reset Password'}
              </h2>
              <button type="button" className="login-popup__close" onClick={handleClose}>
                ×
              </button>
            </div>

            {message.text && (
              <div className={`login-popup__message login-popup__message--${message.type}`}>
                {message.text}
              </div>
            )}

            {view === 'login' ? (
              <form className="login-popup__form" onSubmit={handleLogin}>
                <Input
                  label="Email"
                  type="email"
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  required
                />
                <Input
                  label="Password"
                  type="password"
                  name="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  required
                />
                <button
                  type="button"
                  className="login-popup__forgot"
                  onClick={() => {
                    setView('forgot');
                    setMessage({ type: '', text: '' });
                  }}
                >
                  Forgot password?
                </button>
                <Button type="submit" disabled={loading}>
                  {loading ? 'Signing in...' : 'Login'}
                </Button>
              </form>
            ) : (
              <div className="login-popup__forgot-view">
                <h3>Forgot your password?</h3>
                <p>Enter your email and we will send you a reset link.</p>
                <form className="login-popup__form" onSubmit={handleForgot}>
                  <Input
                    label="Email"
                    type="email"
                    name="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    required
                  />
                  <Button type="submit" disabled={loading}>
                    {loading ? 'Sending...' : 'Send Reset Link'}
                  </Button>
                </form>
                <button
                  type="button"
                  className="login-popup__back"
                  onClick={() => {
                    setView('login');
                    setMessage({ type: '', text: '' });
                  }}
                >
                  ← Back to login
                </button>
              </div>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
